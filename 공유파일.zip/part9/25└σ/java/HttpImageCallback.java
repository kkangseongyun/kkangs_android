package com.example.part9_25;

import android.graphics.Bitmap;

public interface HttpImageCallback {
	
	void onResult(Bitmap d);

}
