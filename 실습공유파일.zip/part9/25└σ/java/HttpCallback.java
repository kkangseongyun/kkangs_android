package com.example.part9_25;

public interface HttpCallback {

	void onResult(String result);
}
